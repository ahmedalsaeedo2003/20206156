package api;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import ejbs.Calculation;

import java.util.List;
@Produces(MediaType.APPLICATION_JSON)
@Stateless
public class CalcuationResults {

	@PersistenceContext(unitName = "yourPersistenceUnitName")
	    private EntityManager entityManager;

	    @GET
	    @Path("/calculations")
	    public Response getAllCalculations() {
	        try {
	            List<Calculation> calculations = entityManager.createQuery("SELECT c FROM Calculation c", Calculation.class)
	                    .getResultList();

	            return Response.status(Response.Status.OK)
	                           .entity(calculations)
	                           .build();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
	                           .entity("Exception occurred: " + e.getMessage())
	                           .build();
	        }
	    }
	    @POST
	    @Path("/calc")
	    public Response createCalculation(Calculation request) {
	        int number1 = request.getNumber1();
	        int number2 = request.getNumber2();
	        String operation = request.getOperation();
	        try {
	            int result;
	            switch (operation) {
	                case "+":
	                    result = number1 + number2;
	                    break;
	                case "-":
	                    result = number1 - number2;
	                    break;
	                case "*":
	                    result = number1 * number2;
	                    break;
	                case "/":
	                    result = number1 / number2;
	                    break;
	                default:
	                    return Response.status(Response.Status.BAD_REQUEST)
	                                   .entity("Invalid operation")
	                                   .build();
	            }

	            Calculation calculation = new Calculation();
	            calculation.setNumber1(number1);
	            calculation.setNumber2(number2);
	            calculation.setOperation(operation);

	            entityManager.persist(calculation);

	            return Response.status(Response.Status.OK)
	                           .entity("{\"Result\": " + result + "}")
	                           .build();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
	                           .entity("Exception occurred: " + e.getMessage())
	                           .build();
	        }
	    }
	}



